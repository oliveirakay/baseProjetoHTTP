
filename = "putNovoArquivo"

print("put" in filename)